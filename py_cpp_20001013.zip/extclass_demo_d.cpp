#define DEBUG_PYTHON
#include "extclass_demo.cpp"
